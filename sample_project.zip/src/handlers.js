// API Request handlers

async function handleLogin(req, res) {
    const { username, password } = req.body;
    
    try {
        const user = await authenticateUser(username, password);
        if (!user) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        const token = generateJWT(user);
        res.json({ token, user: user.toPublic() });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

async function handleGetProfile(req, res) {
    const userId = req.user.id;
    const user = await database.getUser(userId);
    res.json(user.toPublic());
}

function generateJWT(user) {
    return jwt.sign(
        { id: user.id, username: user.username },
        process.env.JWT_SECRET,
        { expiresIn: '24h' }
    );
}
