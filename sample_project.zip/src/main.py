"""Main application module"""

def authenticate_user(username, password):
    """Authenticate user with username and password"""
    if not username or not password:
        raise ValueError("Username and password required")
    
    # Check against database
    user = database.get_user(username)
    if not user or not verify_password(password, user.password_hash):
        return None
    
    return user


def create_session(user):
    """Create user session"""
    session = {
        'user_id': user.id,
        'username': user.username,
        'created_at': datetime.now(),
        'expires_at': datetime.now() + timedelta(hours=24)
    }
    cache.store_session(session)
    return session


def verify_password(plain_password, hash_password):
    """Verify password hash"""
    return bcrypt.checkpw(plain_password.encode(), hash_password)
