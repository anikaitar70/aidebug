# Sample Project

This is a sample project for testing the RAG System.

## Features

- User authentication with JWT
- Session management
- Password hashing with bcrypt
- RESTful API endpoints

## Example Queries

Try asking the RAG system:

1. "How does user authentication work?"
2. "Show me the login handler function"
3. "What database configuration is used?"
4. "How are sessions created?"
5. "What files contain authentication logic?"
